# HyperStore

An Android app catalog that opens only on phones with an unlocked bootloader.

- Unlocked bootloader: the catalog opens. You can browse, search and open apps, and "Get" takes you to the official F-Droid or Google Play page.
- Locked bootloader, or status that cannot be confirmed: the catalog stays closed.

## Change the app list
Edit `app/src/main/res/raw/catalog.json`. Each app has:
`name`, `pkg` (the package name), `cat` (category), `desc`, `fdroid` (true/false), `play` (true/false).
The list is not a copy of every app in the world. It is a catalog you control. Any app can be
found with the "Search Google Play / F-Droid" buttons at the bottom of the store.

## Build the APK
Android Studio (computer): File > Open the HyperStore folder, wait for Gradle sync, then
Build > Build Bundle(s) / APK(s) > Build APK(s).

GitHub (phone or computer): the workflow in `.github/workflows/build.yml` builds
`app-debug.apk` for you. Open the Actions tab and download the `HyperStore-apk` artifact.

## How the check works
The app reads three values the phone reports about its boot state:
`ro.boot.verifiedbootstate` (orange = unlocked), `ro.boot.flash.locked` (0 = unlocked),
`ro.boot.vbmeta.device_state` (unlocked). If they disagree or are missing, access is denied.

## Limits
This check runs inside the app. Someone who edits the app, or hides or fakes these values
(for example with root tools), can get past it. For real enforcement, serve the catalog from a
server and verify Android key attestation or Play Integrity there.
