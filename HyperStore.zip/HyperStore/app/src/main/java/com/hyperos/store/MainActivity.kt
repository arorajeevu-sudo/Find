package com.hyperos.store

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

/**
 * HyperStore: an app catalog that only opens on phones with an unlocked bootloader.
 *
 * The screen is a web page in assets/index.html. The catalog itself lives in
 * res/raw/catalog.json, which is NOT reachable from the web page. It is only handed over
 * by the bridge below, and only when the bootloader check passes.
 *
 * Note: this is a check inside the app. Someone who modifies the app or fakes the phone's
 * system values could get around it. For real enforcement, verify device attestation on a server.
 */
class MainActivity : ComponentActivity() {

    private lateinit var web: WebView

    private data class Boot(
        val state: String,
        val verified: String,
        val flash: String,
        val vbmeta: String
    )

    private var cache: Boot? = null
    private var cacheTime = 0L

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this)
        web.setBackgroundColor(0xFF0B0D12.toInt())
        web.isLongClickable = false
        web.setOnLongClickListener { true }
        setContentView(web)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = false
            allowFileAccess = false
            setSupportZoom(false)
        }

        web.addJavascriptInterface(Bridge(), "AndroidStore")

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean = request.url.host != WebViewAssetLoader.DEFAULT_DOMAIN
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("window.__back?window.__back():false") { result ->
                    if (result != "true") finish()
                }
            }
        })

        web.loadUrl("https://${WebViewAssetLoader.DEFAULT_DOMAIN}/assets/index.html")
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) {
            web.evaluateJavascript("window.__resume&&window.__resume()", null)
        }
    }

    override fun onDestroy() {
        web.removeJavascriptInterface("AndroidStore")
        web.destroy()
        super.onDestroy()
    }

    // ------------------------------------------------------- bootloader check

    private fun prop(key: String): String = try {
        val p = ProcessBuilder("getprop", key).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText().trim()
        p.waitFor()
        out
    } catch (_: Exception) {
        ""
    }

    private fun detect(): Boot {
        val now = System.currentTimeMillis()
        cache?.let { if (now - cacheTime < 3000) return it }

        val verified = prop("ro.boot.verifiedbootstate").lowercase()
        val flash = prop("ro.boot.flash.locked")
        val vbmeta = prop("ro.boot.vbmeta.device_state").lowercase()

        // Signals that say "unlocked": orange verified boot state, flash.locked = 0, vbmeta unlocked.
        val saysUnlocked = verified == "orange" || flash == "0" || vbmeta == "unlocked"
        // Signals that say "locked": green or yellow verified boot state, flash.locked = 1, vbmeta locked.
        val saysLocked = verified == "green" || verified == "yellow" || flash == "1" || vbmeta == "locked"

        // If the signals disagree or nothing is reported, fail closed ("unknown").
        val state = when {
            saysUnlocked && !saysLocked -> "unlocked"
            saysLocked && !saysUnlocked -> "locked"
            else -> "unknown"
        }
        val result = Boot(state, verified, flash, vbmeta)
        cache = result
        cacheTime = now
        return result
    }

    private fun isUnlocked(): Boolean = detect().state == "unlocked"

    // ----------------------------------------------------------------- bridge

    inner class Bridge {

        /** {"state":"unlocked|locked|unknown","verified":..,"flash":..,"vbmeta":..} */
        @JavascriptInterface
        fun bootloader(): String {
            cache = null
            val b = detect()
            return JSONObject()
                .put("state", b.state)
                .put("verified", b.verified)
                .put("flash", b.flash)
                .put("vbmeta", b.vbmeta)
                .toString()
        }

        /** The app list. Returns an empty list unless the bootloader is unlocked. */
        @JavascriptInterface
        fun catalog(): String {
            if (!isUnlocked()) return "[]"
            return try {
                resources.openRawResource(R.raw.catalog).bufferedReader().use { it.readText() }
            } catch (_: Exception) {
                "[]"
            }
        }

        @JavascriptInterface
        fun isInstalled(pkg: String): Boolean {
            if (!isUnlocked()) return false
            return packageManager.getLaunchIntentForPackage(pkg) != null
        }

        @JavascriptInterface
        fun open(pkg: String): Boolean {
            if (!isUnlocked()) return false
            val intent = packageManager.getLaunchIntentForPackage(pkg) ?: return false
            return try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
                true
            } catch (_: Exception) {
                false
            }
        }

        /** Opens an official store page (Google Play via market://, F-Droid via https). */
        @JavascriptInterface
        fun link(url: String) {
            if (!isUnlocked()) return
            val uri = Uri.parse(url)
            val allowed = when (uri.scheme) {
                "market" -> true
                "https" -> uri.host == "f-droid.org" ||
                    uri.host == "search.f-droid.org" ||
                    uri.host == "play.google.com"
                else -> false
            }
            if (!allowed) return
            try {
                startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {
                // No Play Store installed: fall back to the web page.
                val web = when {
                    uri.scheme != "market" -> null
                    uri.host == "search" ->
                        Uri.parse("https://play.google.com/store/search?q=" +
                            Uri.encode(uri.getQueryParameter("q") ?: "") + "&c=apps")
                    else ->
                        Uri.parse("https://play.google.com/store/apps/details?id=" +
                            Uri.encode(uri.getQueryParameter("id") ?: ""))
                }
                if (web != null) {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, web).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }
}
